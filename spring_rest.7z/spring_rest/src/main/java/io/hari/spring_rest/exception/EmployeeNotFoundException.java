package io.hari.spring_rest.exception;

public class EmployeeNotFoundException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public EmployeeNotFoundException(String message)
	{
		super(message);
	}
	public EmployeeNotFoundException(String message, Throwable cause)
	{
		super(message, cause);
	}

}
